<%@page import="DAO.ClienteDAO"%>
<%@page import="Modelo.Cliente"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Validar inicio de sesión
    HttpSession sesion = request.getSession(false);
    if (sesion == null || sesion.getAttribute("nombre") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    String rol = (String) sesion.getAttribute("rol");
    String nombreUsuario = (String) sesion.getAttribute("nombre");
    boolean esVendedor = "Vendedor".equalsIgnoreCase(rol);
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Clientes - Farmacia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<!-- Navegación Dinámica según el Rol -->
    <nav class="navbar navbar-expand-lg navbar-farmacia mb-4">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold" href="ventas.jsp">💊 FARMACIA</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="ventas.jsp">Ventas</a></li>
                    <li class="nav-item"><a class="nav-link active fw-bold" href="clientes.jsp">Clientes</a></li>
                    <li class="nav-item"><a class="nav-link" href="medicamentos.jsp">Medicamentos</a></li>
                    
                    <% if (!esVendedor) { %>
                        <li class="nav-item"><a class="nav-link" href="categorias.jsp">Categorías</a></li>
                        <li class="nav-item"><a class="nav-link" href="pagos.jsp">Pagos</a></li>
                    <% } %>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <span class="text-light small">
                        Usuario: <strong><%= nombreUsuario %></strong> 
                        <span class="badge <%= esVendedor ? "bg-info" : "bg-warning" %> text-dark"><%= rol %></span>
                    </span>
                    <a href="login.jsp" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4">
        <h3 class="mb-4 text-secondary">Gestión de Clientes</h3>

        <div class="row">
            <!-- Formulario de Registro / Edición -->
            <div class="col-md-4 mb-4">
                <div class="card card-custom">
                    <div class="card-header card-header-custom" id="formTitulo">Nuevo Cliente</div>
                    <div class="card-body">
                        <form action="ClienteController" method="POST">
                            <input type="hidden" name="accion" id="accion" value="guardar">
                            <input type="hidden" name="txtid" id="txtid" value="0">

                            <div class="mb-3">
                                <label class="form-label fw-semibold">DNI / Identificación</label>
                                <input type="text" name="txtdni" id="txtdni" class="form-control" placeholder="Ej. 1712345678" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nombre Completo</label>
                                <input type="text" name="txtnombre" id="txtnombre" class="form-control" placeholder="Ej. Juan Pérez" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Teléfono</label>
                                <input type="text" name="txttelefono" id="txttelefono" class="form-control" placeholder="Ej. 0991234567" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Dirección</label>
                                <input type="text" name="txtdireccion" id="txtdireccion" class="form-control" placeholder="Ej. Av. Principal #123" required>
                            </div>
                            
                            <button type="submit" id="btnGuardar" class="btn btn-primary w-100 fw-bold mb-2">Guardar Cliente</button>
                            <button type="button" id="btnCancelar" class="btn btn-secondary w-100 fw-bold d-none" onclick="limpiarFormulario()">Cancelar</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Tabla de Datos -->
            <div class="col-md-8">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>DNI / N° Doc</th>
                                <th>Nombre Completo</th>
                                <th>Teléfono</th>
                                <th>Dirección</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <%
                                ClienteDAO cdao = new ClienteDAO();
                                List<Cliente> lista = cdao.listar();
                                if (lista != null && !lista.isEmpty()) {
                                    for (Cliente c : lista) {
                                        String dniMostrar = (c.getDni() == null) ? "" : c.getDni();
                            %>
                            <tr>
                                <td><%= c.getIdCliente() %></td>
                                <td><%= dniMostrar %></td>
                                <td class="fw-bold"><%= c.getNombre() %></td>
                                <td><%= c.getTelefono() %></td>
                                <td><%= c.getDireccion() %></td>
                                <td class="text-center">
                                    <button class="btn btn-warning btn-sm me-1 fw-semibold" 
                                            onclick="editarCliente('<%= c.getIdCliente() %>', '<%= dniMostrar %>', '<%= c.getNombre() %>', '<%= c.getTelefono() %>', '<%= c.getDireccion() %>')">
                                        ✏️ Editar
                                    </button>
                                    <a href="ClienteController?accion=eliminar&id=<%= c.getIdCliente() %>" 
                                       class="btn btn-danger btn-sm fw-semibold"
                                       onclick="return confirm('¿Seguro de eliminar este cliente?');">
                                        🗑️ Eliminar
                                    </a>
                                </td>
                            </tr>
                            <%
                                    }
                                } else {
                            %>
                            <tr>
                                <td colspan="6" class="text-center text-muted">No hay clientes registrados en la Base de Datos</td>
                            </tr>
                            <%
                                }
                            %>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editarCliente(id, dni, nombre, telefono, direccion) {
            document.getElementById('txtid').value = id;
            document.getElementById('txtdni').value = dni;
            document.getElementById('txtnombre').value = nombre;
            document.getElementById('txttelefono').value = telefono;
            document.getElementById('txtdireccion').value = direccion;
            
            document.getElementById('accion').value = 'modificar';
            document.getElementById('formTitulo').innerText = 'Editar Cliente ID: ' + id;
            document.getElementById('btnGuardar').innerText = 'Actualizar Cliente';
            document.getElementById('btnGuardar').className = 'btn btn-warning w-100 fw-bold mb-2';
            document.getElementById('btnCancelar').classList.remove('d-none');
        }

        function limpiarFormulario() {
            document.getElementById('txtid').value = '0';
            document.getElementById('txtdni').value = '';
            document.getElementById('txtnombre').value = '';
            document.getElementById('txttelefono').value = '';
            document.getElementById('txtdireccion').value = '';
            
            document.getElementById('accion').value = 'guardar';
            document.getElementById('formTitulo').innerText = 'Nuevo Cliente';
            document.getElementById('btnGuardar').innerText = 'Guardar Cliente';
            document.getElementById('btnGuardar').className = 'btn btn-primary w-100 fw-bold mb-2';
            document.getElementById('btnCancelar').classList.add('d-none');
        }
    </script>
</body>
</html>