<%-- 
    Document   : login
    Created on : 14 ago 2026, 10:11:00 a. m.
    Author     : LABH5-PC-11
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso al Sistema - Farmacia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f4f6f9;
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            padding: 2.5rem;
            border-radius: 12px;
            background: #ffffff;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="text-center mb-4">
            <h3 class="text-primary fw-bold">💊 FARMACIA</h3>
            <p class="text-muted small">Ingresa tus credenciales para acceder</p>
        </div>

        <!-- Alerta de error si falla el login -->
        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-danger p-2 text-center small" role="alert">
                <%= request.getAttribute("error") %>
            </div>
        <% } %>

        <!-- Formulario vinculado con UsuarioController -->
        <form action="UsuarioController" method="POST">
            <input type="hidden" name="accion" value="login">

            <div class="mb-3 text-start">
                <label class="form-label fw-semibold">Usuario</label>
                <input type="text" name="txtusuario" class="form-control" placeholder="Ej. admin" required>
            </div>

            <div class="mb-3 text-start">
                <label class="form-label fw-semibold">Contraseña</label>
                <input type="password" name="txtclave" class="form-control" placeholder="******" required>
            </div>

            <button type="submit" class="btn btn-primary w-100 fw-bold mt-2">Ingresar</button>
        </form>
    </div>

</body>
</html>