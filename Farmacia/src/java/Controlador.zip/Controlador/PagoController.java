package Controlador;

import DAO.PagoDAO;
import Modelo.Pago;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "PagoController", urlPatterns = {"/PagoController"})
public class PagoController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        
        if ("guardar".equalsIgnoreCase(accion)) {
            int idVenta = Integer.parseInt(request.getParameter("txtidventa"));
            String metodoPago = request.getParameter("txtmetodo");
            double monto = Double.parseDouble(request.getParameter("txtmonto"));

            Pago p = new Pago();
            p.setIdVenta(idVenta);
            p.setMetodoPago(metodoPago);
            p.setMonto(monto);

            PagoDAO pdao = new PagoDAO();
            pdao.registrarPago(p);
        }
        
        response.sendRedirect("pagos.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}