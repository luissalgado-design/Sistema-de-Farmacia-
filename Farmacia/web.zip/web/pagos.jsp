<%@page import="DAO.PagoDAO"%>
<%@page import="Modelo.Pago"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Validar inicio de sesión
    HttpSession sesion = request.getSession(false);
    if (sesion == null || sesion.getAttribute("nombre") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    String rol = (String) sesion.getAttribute("rol");
    String nombreUsuario = (String) sesion.getAttribute("nombre");
    boolean esVendedor = "Vendedor".equalsIgnoreCase(rol);

    // Restricción de acceso para vendedores
    if (esVendedor) {
        response.sendRedirect("ventas.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pagos - Farmacia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

    <!-- Navegación Dinámica -->
    <nav class="navbar navbar-expand-lg navbar-farmacia mb-4">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold" href="ventas.jsp">💊 FARMACIA</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="ventas.jsp">Ventas</a></li>
                    <li class="nav-item"><a class="nav-link" href="clientes.jsp">Clientes</a></li>
                    <li class="nav-item"><a class="nav-link" href="medicamentos.jsp">Medicamentos</a></li>
                    <li class="nav-item"><a class="nav-link" href="categorias.jsp">Categorías</a></li>
                    <li class="nav-item"><a class="nav-link active fw-bold" href="pagos.jsp">Pagos</a></li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <span class="text-light small">
                        Usuario: <strong><%= nombreUsuario %></strong> 
                        <span class="badge bg-warning text-dark"><%= rol %></span>
                    </span>
                    <a href="login.jsp" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4">
        <h3 class="mb-4 text-secondary">Consulta y Registro de Pagos</h3>

        <div class="row">
            <!-- Formulario de Registro de Pago -->
            <div class="col-md-4 mb-4">
                <div class="card card-custom">
                    <div class="card-header card-header-custom">Registrar Nuevo Pago</div>
                    <div class="card-body">
                        <form action="PagoController" method="POST">
                            <input type="hidden" name="accion" value="guardar">

                            <div class="mb-3">
                                <label class="form-label fw-semibold">ID de Venta</label>
                                <input type="number" name="txtidventa" class="form-control" placeholder="Ej: 1001" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Método de Pago</label>
                                <select name="txtmetodo" class="form-select" required>
                                    <option value="" selected disabled>Seleccione...</option>
                                    <option value="Efectivo">Efectivo</option>
                                    <option value="Tarjeta de Crédito/Débito">Tarjeta de Crédito/Débito</option>
                                    <option value="Transferencia">Transferencia</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Monto ($)</label>
                                <input type="number" step="0.01" name="txtmonto" class="form-control" placeholder="0.00" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 fw-bold">Registrar Pago</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Tabla de Historial de Pagos -->
            <div class="col-md-8">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle">
                        <thead>
                            <tr>
                                <th>ID Pago</th>
                                <th>ID Venta</th>
                                <th>Método de Pago</th>
                                <th>Monto Total</th>
                                <th>Fecha de Pago</th>
                            </tr>
                        </thead>
                        <tbody>
                            <%
                                PagoDAO pdao = new PagoDAO();
                                List<Pago> listaPagos = pdao.listar();
                                if (listaPagos != null && !listaPagos.isEmpty()) {
                                    for (Pago p : listaPagos) {
                            %>
                            <tr>
                                <td><%= p.getIdPago() %></td>
                                <td><span class="badge bg-secondary">Venta #<%= p.getIdVenta() %></span></td>
                                <td class="fw-bold"><%= p.getMetodoPago() %></td>
                                <td class="text-success fw-bold">$<%= String.format("%.2f", p.getMonto()) %></td>
                                <td class="text-muted"><%= p.getFechaPago() != null ? p.getFechaPago() : "N/A" %></td>
                            </tr>
                            <%
                                    }
                                } else {
                            %>
                            <tr>
                                <td colspan="5" class="text-center text-muted">No hay pagos registrados.</td>
                            </tr>
                            <%
                                }
                            %>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>