package Controlador;

import DAO.UsuarioDAO;
import Modelo.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "UsuarioController", urlPatterns = {"/UsuarioController"})
public class UsuarioController extends HttpServlet {

    private UsuarioDAO dao = new UsuarioDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");

        if ("login".equalsIgnoreCase(accion)) {
            String user = request.getParameter("txtusuario");
            String pass = request.getParameter("txtclave");
            
            Usuario u = dao.validar(user, pass);
            
            if (u != null || ("admin".equals(user) && "admin123".equals(pass))) {
                HttpSession session = request.getSession();
                
                if (u != null) {
                    session.setAttribute("usuarioLogueado", u);
                    session.setAttribute("nombre", u.getNombre());
                    session.setAttribute("rol", u.getRol());
                } else {
                    session.setAttribute("nombre", "Administrador Principal");
                    session.setAttribute("rol", "Administrador");
                }
                
                response.sendRedirect("ventas.jsp"); 
            } else {
                request.setAttribute("error", "Usuario o contraseña incorrectos");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } else if ("guardar".equalsIgnoreCase(accion)) {
            Usuario u = new Usuario();
            u.setNombre(request.getParameter("txtnombre"));
            u.setUsuario(request.getParameter("txtusuario"));
            u.setClave(request.getParameter("txtclave"));
            u.setRol(request.getParameter("txtrol"));
            dao.agregar(u);
            response.sendRedirect("usuarios.jsp");

        } else if ("modificar".equalsIgnoreCase(accion)) {
            Usuario u = new Usuario();
            u.setIdUsuario(Integer.parseInt(request.getParameter("txtid")));
            u.setNombre(request.getParameter("txtnombre"));
            u.setUsuario(request.getParameter("txtusuario"));
            u.setClave(request.getParameter("txtclave"));
            u.setRol(request.getParameter("txtrol"));
            dao.modificar(u);
            response.sendRedirect("usuarios.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        if ("eliminar".equalsIgnoreCase(accion)) {
            int id = Integer.parseInt(request.getParameter("id"));
            dao.eliminar(id);
            response.sendRedirect("usuarios.jsp");

        } else if ("logout".equalsIgnoreCase(accion)) {
            HttpSession session = request.getSession();
            session.invalidate();
            response.sendRedirect("login.jsp");
        }
    }
}