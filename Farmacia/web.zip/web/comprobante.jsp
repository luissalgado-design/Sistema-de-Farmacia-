<%@page import="DAO.DetalleVentaDAO"%>
<%@page import="DAO.MedicamentoDAO"%>
<%@page import="DAO.VentaDAO"%>
<%@page import="Modelo.DetalleVenta"%>
<%@page import="Modelo.Medicamento"%>
<%@page import="Modelo.Venta"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Obtener idVenta de la URL
    String idVentaStr = request.getParameter("idVenta");
    int idVenta = 0;
    try {
        if (idVentaStr != null) {
            idVenta = Integer.parseInt(idVentaStr);
        }
    } catch (NumberFormatException e) {
        idVenta = 0;
    }

    VentaDAO vdao = new VentaDAO();
    DetalleVentaDAO dvdao = new DetalleVentaDAO();
    MedicamentoDAO mdao = new MedicamentoDAO();

    // Buscar venta y sus detalles
    Venta venta = (idVenta > 0) ? vdao.buscarPorId(idVenta) : null;
    List<DetalleVenta> detalles = (idVenta > 0) ? dvdao.listarPorVenta(idVenta) : null;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Comprobante de Venta #<%= idVenta %></title>
    <link href="https://cdn.jsdelivr.net/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; font-family: monospace; }
        .ticket { max-width: 400px; margin: 30px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        @media print {
            .no-print { display: none; }
            .ticket { box-shadow: none; margin: 0; width: 100%; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="ticket">
        <div class="text-center mb-3">
            <h4 class="fw-bold mb-0">FARMACIA</h4>
            <small class="text-muted">Comprobante de Venta</small>
            <hr>
        </div>

        <% if (venta != null) { %>
            <div class="row mb-2 small">
                <div class="col-6"><strong>N° Venta:</strong> #<%= venta.getIdVenta() %></div>
                <div class="col-6 text-end"><strong>Cliente ID:</strong> <%= venta.getIdCliente() %></div>
            </div>
            <div class="row mb-3 small">
                <div class="col-6">
                    <span class="text-muted">Fecha:</span><br>
                    <strong><%= venta.getFechaVenta() != null ? venta.getFechaVenta() : "N/A" %></strong>
                </div>
                <div class="col-6 text-end">
                    <span class="text-muted">Estado:</span><br>
                    <span class="badge bg-success"><%= venta.getEstado() %></span>
                </div>
            </div>

            <table class="table table-sm text-start small">
                <thead>
                    <tr>
                        <th>Cant</th>
                        <th>Producto</th>
                        <th class="text-end">P.Unit</th>
                        <th class="text-end">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        if (detalles != null && !detalles.isEmpty()) {
                            for (DetalleVenta d : detalles) {
                                Medicamento m = mdao.buscarPorId(d.getIdMedicamento());
                                String nombreMed = (m != null) ? m.getNombre() : "Producto #" + d.getIdMedicamento();
                    %>
                    <tr>
                        <td><%= d.getCantidad() %></td>
                        <td><%= nombreMed %></td>
                        <td class="text-end">$<%= String.format("%.2f", d.getPrecioUnitario()) %></td>
                        <td class="text-end">$<%= String.format("%.2f", d.getSubtotal()) %></td>
                    </tr>
                    <%
                            }
                        } else {
                    %>
                    <tr>
                        <td colspan="4" class="text-center text-muted">Sin detalles registrados</td>
                    </tr>
                    <% } %>
                </tbody>
            </table>

            <hr>
            <div class="d-flex justify-content-between fs-5 fw-bold text-dark">
                <span>TOTAL:</span>
                <span class="text-success">$<%= String.format("%.2f", venta.getTotal()) %></span>
            </div>
        <% } else { %>
            <div class="alert alert-warning text-center">
                No se encontró el comprobante para la venta ID: <strong><%= idVenta %></strong>
            </div>
        <% } %>

        <div class="mt-4 no-print d-flex gap-2">
            <button onclick="window.print()" class="btn btn-primary w-50">Imprimir</button>
            <a href="ventas.jsp" class="btn btn-secondary w-50">Volver</a>
        </div>
    </div>
</div>

</body>
</html>