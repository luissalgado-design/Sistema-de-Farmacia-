<%@page import="DAO.CategoriaDAO"%>
<%@page import="Modelo.Categoria"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Validar inicio de sesión
    HttpSession sesion = request.getSession(false);
    if (sesion == null || sesion.getAttribute("nombre") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    String rol = (String) sesion.getAttribute("rol");
    String nombreUsuario = (String) sesion.getAttribute("nombre");
    boolean esVendedor = "Vendedor".equalsIgnoreCase(rol);

    // Protección de ruta: Si es Vendedor, se redirige a ventas con mensaje de error
    if (esVendedor) {
        response.sendRedirect("medicamentos.jsp?error=unauthorized");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Categorías - Farmacia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

    <!-- Navegación Dinámica según el Rol -->
    <nav class="navbar navbar-expand-lg navbar-farmacia mb-4">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold" href="ventas.jsp">💊 FARMACIA</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="ventas.jsp">Ventas</a></li>
                    <li class="nav-item"><a class="nav-link" href="clientes.jsp">Clientes</a></li>
                    <li class="nav-item"><a class="nav-link active fw-bold" href="categorias.jsp">Categorías</a></li>
                    <li class="nav-item"><a class="nav-link" href="medicamentos.jsp">Medicamentos</a></li>
                    <li class="nav-item"><a class="nav-link" href="pagos.jsp">Pagos</a></li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <span class="text-light small">
                        Usuario: <strong><%= nombreUsuario %></strong> 
                        <span class="badge bg-warning text-dark"><%= rol %></span>
                    </span>
                    <a href="login.jsp" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <h3 class="mb-4 text-secondary">Gestión de Categorías</h3>

        <div class="row">
            <!-- Formulario de Registro / Edición -->
            <div class="col-md-4 mb-4">
                <div class="card card-custom">
                    <div class="card-header card-header-custom" id="formTitulo">Nueva Categoría</div>
                    <div class="card-body">
                        <form action="CategoriaController" method="POST">
                            <input type="hidden" name="accion" id="accion" value="guardar">
                            <input type="hidden" name="txtid" id="txtid" value="0">

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nombre</label>
                                <input type="text" name="txtnombre" id="txtnombre" class="form-control" placeholder="Ej. Analgésicos" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Descripción</label>
                                <textarea name="txtdescripcion" id="txtdescripcion" class="form-control" rows="3" placeholder="Descripción breve..." required></textarea>
                            </div>
                            
                            <button type="submit" id="btnGuardar" class="btn btn-primary w-100 fw-bold mb-2">Guardar Categoría</button>
                            <button type="button" id="btnCancelar" class="btn btn-secondary w-100 fw-bold d-none" onclick="limpiarFormulario()">Cancelar</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Tabla Dinámica -->
            <div class="col-md-8">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <%
                                CategoriaDAO cdao = new CategoriaDAO();
                                List<Categoria> listaCat = cdao.listar();
                                if (listaCat != null && !listaCat.isEmpty()) {
                                    for (Categoria c : listaCat) {
                            %>
                            <tr>
                                <td><%= c.getIdCategoria() %></td>
                                <td class="fw-bold"><%= c.getNombre() %></td>
                                <td><%= c.getDescripcion() %></td>
                                <td class="text-center">
                                    <button class="btn btn-warning btn-sm me-1 fw-semibold" 
                                            onclick="editarCategoria('<%= c.getIdCategoria() %>', '<%= c.getNombre() %>', '<%= c.getDescripcion() %>')">
                                        ✏️ Editar
                                    </button>
                                    <a href="CategoriaController?accion=eliminar&id=<%= c.getIdCategoria() %>" 
                                       class="btn btn-danger btn-sm fw-semibold"
                                       onclick="return confirm('¿Seguro de eliminar esta categoría?');">
                                        🗑️ Eliminar
                                    </a>
                                </td>
                            </tr>
                            <%
                                    }
                                } else {
                            %>
                            <tr>
                                <td colspan="4" class="text-center text-muted">No hay categorías registradas</td>
                            </tr>
                            <%
                                }
                            %>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editarCategoria(id, nombre, descripcion) {
            document.getElementById('txtid').value = id;
            document.getElementById('txtnombre').value = nombre;
            document.getElementById('txtdescripcion').value = descripcion;
            
            document.getElementById('accion').value = 'modificar';
            document.getElementById('formTitulo').innerText = 'Editar Categoría ID: ' + id;
            document.getElementById('btnGuardar').innerText = 'Actualizar Categoría';
            document.getElementById('btnGuardar').className = 'btn btn-warning w-100 fw-bold mb-2';
            document.getElementById('btnCancelar').classList.remove('d-none');
        }

        function limpiarFormulario() {
            document.getElementById('txtid').value = '0';
            document.getElementById('txtnombre').value = '';
            document.getElementById('txtdescripcion').value = '';
            
            document.getElementById('accion').value = 'guardar';
            document.getElementById('formTitulo').innerText = 'Nueva Categoría';
            document.getElementById('btnGuardar').innerText = 'Guardar Categoría';
            document.getElementById('btnGuardar').className = 'btn btn-primary w-100 fw-bold mb-2';
            document.getElementById('btnCancelar').classList.add('d-none');
        }
    </script>
</body>
</html>